<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Diet_Shop
 */

?>


<?php do_action( 'diet_shop_load_footer' );?>

			<!-- Scroll Top Button -->
			


    
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
